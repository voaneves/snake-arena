# Comece aqui

Estado em 12 de agosto de 2026. **O código está pronto e testado; o benchmark ainda não foi
rodado.** Este documento diz exatamente o que fazer, nessa ordem.

## 1. Versionar o que está no disco (2 minutos)

O repositório local tem um commit só e tudo o mais está solto. No PowerShell:

```powershell
cd D:\GitHub\snake-arena
git add -A
git commit -m "snake-arena: pacote completo, 9 algoritmos, 424 testes"
```

Se sobrou uma pasta `_to_delete\`, pode apagar — são notebooks com a numeração antiga.

## 2. Publicar no GitHub (5 minutos)

**Isto é pré-requisito para os badges "Open in Colab" funcionarem.** Eles apontam para
`github.com/voaneves/snake-arena`, que ainda não existe. Sem isso os notebooks continuam
utilizáveis — é só fazer upload manual no Colab — mas o botão não abre.

```powershell
gh repo create voaneves/snake-arena --public --source=. --push
```

## 3. Rodar o benchmark (é aqui que o gráfico se preenche)

Cada notebook é autocontido: **suba o `.ipynb` e rode**. Nada de clonar. O mesmo arquivo
roda no **Colab**, no **Kaggle** e na sua máquina — ele detecta onde está e escolhe a pasta
que persiste em cada um.

**Kaggle costuma render mais no plano gratuito**, e por uma razão estrutural além da cota:
ele tem execução *headless*. Em *Save Version → Save & Run All* o notebook roda inteiro sem
aba aberta, e a saída vira um artefato versionado — não há o que "cair por inatividade".

| | Colab | Kaggle |
|---|---|---|
| acelerador | `Runtime → Change runtime type → GPU` | `Settings → Accelerator → GPU` |
| onde persiste | Google Drive (`USAR_DRIVE = True`) | `/kaggle/working`, automático |
| retomar depois da queda | o Drive continua lá, rode a célula de novo | *Add Input → Your Work → Notebook Output*, apontando para a execução anterior |
| baixar o resultado | download pelo navegador, exige a aba aberta | painel **Output**, funciona com a aba fechada |

No Kaggle, `/kaggle/working` vira a **saída daquela versão** — ele não volta sozinho na
sessão seguinte. Anexar a saída anterior é o que faz a retomada funcionar, e a célula de
parâmetros recupera os checkpoints de lá sozinha.

Ordem sugerida, por retorno sobre o tempo:

| # | notebook | por quê |
|---|---|---|
| 1 | `06_alphazero.ipynb` | candidato mais forte. **Use `num_simulations` entre 64 e 128** — com 12 a destilação não funciona, e isso está medido |
| 2 | `01_ppo.ipynb` | a referência; tudo é lido contra ela |
| 3 | `03_rainbow.ipynb` | o topo da linhagem DQN |
| 4 | `02_dqn.ipynb` | a base, para o Rainbow ter contra o que ser comparado |
| 5 | `04_a2c.ipynb` | o controle experimental do PPO |
| 6 | `08_acktr.ipynb` | **rode logo depois do A2C.** Só faz sentido lido contra ele: é o mesmo algoritmo com o gradiente natural ligado, e a diferença entre as duas curvas é a resposta para "vale a pena aproximar a curvatura?" |
| 7 | `07_muzero.ipynb` | responde "quanto custa não ter o simulador" |
| 8 | `05_acer.ipynb` | o mais difícil; já se sabe que converge |
| 9 | `09_dreamerv3.ipynb` | **o mais caro por passo de ambiente.** Comece com `preset="dreamer_tiny"` para ver a curva subir antes de gastar GPU no `dreamer_small` |
| 10 | `99_ablacoes.ipynb` | arquitetura e otimizador, os dois eixos que 2019 nunca mediu |

Cada um roda três vezes, com `SEMENTE` em 0, 1 e 2. Deixe `PASSOS` no padrão: o contrato
exige o mesmo orçamento para todos, e o notebook avisa se você mudar.

`USAR_DRIVE` já vem ligado — o notebook vai pedir para montar o Drive na primeira célula.
A sessão do Colab vai cair; com o Drive o treino continua de onde parou, sem o Drive
recomeça do zero. Desligue só se for um teste rápido que você não pretende retomar.

A última célula empacota a execução inteira — registro, curva, GIFs e o modelo exportado —
num `.zip` só e dispara o download. Se a aba não estiver aberta na hora, ela imprime o
caminho do `.zip` em vez de falhar calada.

## 4. Montar a arena

Baixe as pastas `runs/` do Drive, coloque em `runs/` do repositório e:

```powershell
python -m snakeai.arena --all
```

Ele regenera `assets/arena_light.png`, `assets/arena_dark.png` e `docs/RESULTADOS.md`.
Execuções que não obedecerem ao contrato aparecem listadas como excluídas, com o motivo.

## O que ainda não existe

- **Nenhum resultado oficial.** O gráfico está vazio de propósito.
- **`models/`** vazio — se enche quando houver o que exportar.
- **CI** não configurado. `pytest` roda local em ~6 minutos.
- **Os repositórios antigos** (`snake-on-pygame`, `colab-rl`) ainda não apontam para cá, e
  os três bugs de estado do `snake.py` continuam lá.

## Se algo quebrar

`pytest` da raiz. São 347 testes e a mensagem de falha foi escrita para dizer o que
quebrou, não só que quebrou.
